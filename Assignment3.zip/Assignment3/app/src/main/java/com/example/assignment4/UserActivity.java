package com.example.assignment4;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class UserActivity extends AppCompatActivity {

    final String TAG = "demo";
    EditText editTextName, editTextEmail;
    RadioGroup radioGroupRole;
    RadioButton buttonStudent;
    RadioButton buttonEmployee;

    RadioButton buttonOthers;
    Button buttonNext;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_user);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        editTextName = findViewById(R.id.editTextName);
        editTextEmail = findViewById(R.id.textEmail);
        radioGroupRole = findViewById(R.id.radioGroup);
        buttonNext = findViewById(R.id.nextButton);
        buttonStudent = findViewById(R.id.radioButtonStudent);
        buttonEmployee = findViewById(R.id.radioButtonEmployee);
        buttonOthers = findViewById(R.id.radioButtonOther);


        buttonNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = editTextName.getText().toString().trim();
                String email = editTextEmail.getText().toString().trim();
                String role = getSelectedRole();

                if (name.isEmpty() || email.isEmpty() || role == null) {
                    Toast.makeText(UserActivity.this, "All fields are required.", Toast.LENGTH_LONG).show();
                } else {
                    User user = new User(name, email, role);
                    Intent intent = new Intent(UserActivity.this, ProfileActivity.class);
                    intent.putExtra("user", user);
                    startActivity(intent);
                    finish();
                }
            }
        });
    }

    private String getSelectedRole() {
        int selectedId = radioGroupRole.getCheckedRadioButtonId();
        if (selectedId != -1) {
            RadioButton selectedRole = findViewById(selectedId);
            return selectedRole.getText().toString();
        }
        return null;
    }
}