package com.example.assignment4;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;

public class EditUserActivity extends AppCompatActivity {

    EditText textName, textEmail;
    RadioGroup radioGroupRole;
    Button cancel;
    Button submit;
    User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.edit_user);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        textName = findViewById(R.id.textName);
        textEmail = findViewById(R.id.textEmail);
        radioGroupRole = findViewById(R.id.radioGroup);
        cancel = findViewById(R.id.cancel_button);
        submit = findViewById(R.id.submit_button);
        user = (User) getIntent().getSerializableExtra("user");

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = textName.getText().toString();    //.trim();
                String email = textEmail.getText().toString();  //.trim();
                String role = getSelectedRole();

                if (name.isEmpty() || email.isEmpty() || role == null) {
                    Toast.makeText(EditUserActivity.this, "All fields are required.", Toast.LENGTH_LONG).show();
                } else {
                  /*  User user = (User) getIntent().getSerializableExtra("user");
                    user.name = name;
                    user.email = email;
                    user.role = role;
                   */
                    Log.d("myTag","created--");

                    user = new User(name, email, role);
                    Intent intentResult = new Intent();
                    intentResult.putExtra("user", user);
                    setResult(RESULT_OK, intentResult);
                    finish();
                }
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
        } });
    }



    private String getSelectedRole() {
        int selectedId = radioGroupRole.getCheckedRadioButtonId();
        if (selectedId != -1) {
            RadioButton selectedRole = findViewById(selectedId);
            return selectedRole.getText().toString();
        }
        return null;
    }


}

